import bpy
from bpy import context
import random as rand 
from math import radians 

bl_info = {
    "name": "Match Rotate",
    "author": "Jake Henson",
    "version": (1, 0), 
    "blender": (2, 83, 0),
    "location": "View3D > Object Mode > Object Context Menu (or Right Click on Objects)",
    "description": "Match all selected objects' rotation to the active object",
    "warning": "",
    "doc_url": "https://github.com/RadArcadeKid/matchrotate-bl-addon",
    "category": "Object",
}



class MatchRotate(bpy.types.Operator): 
    """Match all selected objects' rotation to the active object"""
    bl_idname = "object.match_rotate"
    bl_label = "Match Rotate"
    bl_options = {'REGISTER', 'UNDO'}

    mesh_only: bpy.props.BoolProperty(
        name="Mesh Objects Only: ",
        description="If set to true, only mesh objects will be rotated along with the active object. If false, all objects will be rotated.",
        default=False
    )
    
    include_active: bpy.props.BoolProperty(
        name="Include Active Object: ",
        description="If set to true, the active object will be rotated alongside the rest. Useful with random variance",
        default=False
    )
    
    x_match_rot: bpy.props.BoolProperty(
        name="Match Axis:     X  ",
        description="Match the active object's x-axis rotation",
        default=True
    )
    
    y_match_rot: bpy.props.BoolProperty(
        name="Y  ",
        description="Match the active object's y-axis rotation",
        default=True
    )
    
    z_match_rot: bpy.props.BoolProperty(
        name="Z  ",
        description="Match the active object's z-axis rotation",
        default=True
    )
    
    
    ##TODO: Random rotation variance? 
    rand_variance: bpy.props.IntProperty(
        name="Random Variance: ",
        description="How much random rotation variance each object has compared to the active object's rotation. (Leave at 0 for no variance)", 
        default=0,
        min=0,
        max=360,
        subtype='ANGLE'
    )
                    
    
    def execute(self, context):
        scene = context.scene

        if(bpy.context.active_object == 'NoneType'):
            self.report({'ERROR_INVALID_INPUT'}, 'Select an ACTIVE object to rotate to. Defaulting to (0,0,0)...')
            dx, dy, dz, = 0, 0, 0
            return {'CANCELLED'}
        else:
            dx, dy, dz = bpy.context.active_object.rotation_euler


        #update selected objects 
        selected_objects = bpy.context.selected_objects
        
        #exclude active object by default (doesn't need to be rotated) 
        if(self.include_active == False):
            selected_objects.remove(bpy.context.active_object)
        
       
        #exclude meshes if necessary 
        if(self.mesh_only): 
            for obj in selected_objects:
                if(obj.type != 'MESH'):
                    obj.select_set(False) #deselect first
                    selected_objects.remove(obj) #then remove from the list 
        
        
        
        #ROTATE OBJECTS 
        for i in range(len(selected_objects)):
            variance = radians(self.rand_variance) #convert to radians for consistency 
            
            #add variance to rotation if requested  
            if(variance != 0.0):
                #randomize each variable 
                dx = dx + rand.uniform(-variance, variance)
                dy = dy + rand.uniform(-variance, variance)
                dz = dz + rand.uniform(-variance, variance)
            
            #match rotations to desired rotations 
            if(self.x_match_rot): 
                selected_objects[i].rotation_euler.x = dx 
            
            if(self.y_match_rot): 
                selected_objects[i].rotation_euler.y = dy
         
            if(self.z_match_rot): 
                selected_objects[i].rotation_euler.z = dz  
                
        
        return {'FINISHED'}
  
  
  
def draw_inmenu(self, context):
    self.layout.operator("object.match_rotate", text="Match Rotate", icon='FILE_REFRESH')
    
    
def register():
    bpy.utils.register_class(MatchRotate)
    bpy.types.VIEW3D_MT_object_context_menu.append(draw_inmenu)


def unregister():
    bpy.utils.unregister_class(MatchRotate)
    bpy.types.VIEW3D_MT_object_context_menu.remove(draw_inmenu)


if __name__ == "__main__":
    register()
    
    

# ##### CREDITS #####
# Program developed and designed by Jake Henson, August 2020 
# Special thanks to you, the person reading this, for downloading my addon.  
#
# As stated by the GPL license, you may add on, expand upon, edit, transform this to your liking.
# The author claims no commercial or financial interest in this tool, especially given the open-source nature
# of Blender and many other free addons. This is merely designed for fun and productivity. 
# This addon is and always will be free. 
# I respectfully ask that you do not sell this code for profit and/or claim it as your own. 
# ###################



# ##### GPL LICENSE #####
#This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.

#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.

#   For more information, see <https://www.gnu.org/licenses/>.
# #######################
